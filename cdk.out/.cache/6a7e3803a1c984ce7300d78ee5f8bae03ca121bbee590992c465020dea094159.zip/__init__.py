from notifications import handler
handler(event, context)